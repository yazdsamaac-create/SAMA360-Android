package ir.sama360.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    LinearLayout content;
    int blue = Color.rgb(22,59,101);

    TextView text(String s, int size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setPadding(18,18,18,18);
        return t;
    }

    Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(10,10,10,10);

        TextView head = text("سما ۳۶۰\nاکوسیستم یکپارچه روابط عمومی سما استان یزد", 21);
        head.setTextColor(Color.WHITE);
        head.setBackgroundColor(blue);
        root.addView(head);

        LinearLayout nav = new LinearLayout(this);
        String[] menus = {"داشبورد","مدارس","مخاطبان","رسانه","گزارش‌ها"};
        for (String m : menus) {
            Button b = button(m);
            nav.addView(b, new LinearLayout.LayoutParams(0,-2,1));
            b.setOnClickListener(v -> show(m));
        }
        root.addView(nav);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        show("داشبورد");
    }

    void show(String m) {
        content.removeAllViews();
        if (m.equals("داشبورد")) {
            content.addView(text("اتاق فرمان سما ۳۶۰",22));
            content.addView(text("مدارس فعال: ۳۵\nمخاطبان: ۸۴۲\nاخبار امروز: ۱۲\nمنتظر تأیید: ۶",18));
        } else if (m.equals("مدارس")) {
            content.addView(text("مدیریت مدارس",22));
            content.addView(text("ساختار چندمدرسه‌ای؛ بدون محدودیت سخت برای تعداد مدارس.",17));
        } else if (m.equals("مخاطبان")) {
            content.addView(text("مخاطب ۳۶۰",22));
            EditText n = new EditText(this); n.setHint("نام مخاطب"); content.addView(n);
            EditText p = new EditText(this); p.setHint("شماره همراه"); content.addView(p);
            Button b = button("ثبت مخاطب"); content.addView(b);
            b.setOnClickListener(v -> Toast.makeText(this,"مخاطب ثبت شد",Toast.LENGTH_SHORT).show());
        } else if (m.equals("رسانه")) {
            content.addView(text("موتور خبر و رسانه",22));
            EditText title = new EditText(this); title.setHint("عنوان یا شرح کوتاه رویداد"); content.addView(title);
            EditText detail = new EditText(this); detail.setHint("چه اتفاقی؟ چه کسی؟ کجا؟ چه زمانی؟ نتیجه؟"); detail.setMinLines(5); content.addView(detail);
            Button b = button("تکمیل هوشمند خبر"); content.addView(b);
            TextView out = text("",16); content.addView(out);
            b.setOnClickListener(v -> out.setText("پیش‌نویس خبر مادر آماده بررسی است.\nوضعیت: نیازمند راستی‌آزمایی انسانی."));
        } else {
            content.addView(text("گزارش‌های مدیریتی",22));
            content.addView(text("گزارش مدارس، CRM، رسانه، KPI و گردش‌کار.",17));
        }
    }
}
